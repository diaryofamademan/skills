# Hugeicons (free) — MIT License

Icons in this folder are from the **Hugeicons free** set (Stroke Rounded style), exported from [`@hugeicons/core-free-icons`](https://www.npmjs.com/package/@hugeicons/core-free-icons) (v4.4.0) and/or [hugeicons/hugeicons](https://github.com/hugeicons/hugeicons/tree/main/icons).

Stroke color was set to `#6E7FD6` for readability on GitHub light (`#ffffff`) and dark (`#0d1117`) themes.

**Do not use Hugeicons Pro** (`@hugeicons-pro/*`) in this repo — Pro icons are not redistributable.

---

MIT License

Copyright (c) 2025 Hugeicons

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
